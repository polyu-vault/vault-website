/* Additional JavaScript for thrifty. */
