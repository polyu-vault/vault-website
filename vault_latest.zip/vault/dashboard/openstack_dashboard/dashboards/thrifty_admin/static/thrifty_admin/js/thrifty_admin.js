/* Additional JavaScript for thrifty_admin. */
