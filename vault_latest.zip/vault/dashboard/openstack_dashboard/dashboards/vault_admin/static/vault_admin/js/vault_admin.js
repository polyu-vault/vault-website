/* Additional JavaScript for vault_admin. */
