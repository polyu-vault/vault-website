/* Additional JavaScript for vault. */
