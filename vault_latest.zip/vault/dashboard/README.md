# Thrifty Dashboard on OpenStack Horizon
## Installation instruction
### 1.Change the host ip of urls in the following files to the current host ip.
* openstack_dashboard/dashboards/thrifty_admin/tenant_mppdb_group_status/templates/tenant_mppdb_group_status/index.html
* openstack_dashboard/dashboards/thrifty_admin/tenant_mppdb_status/templates/tenant_mppdb_status/index.html
* thrifty/constant.py

### 2.Copy files to corresponding directories.

openstack_dashboard/dashboards/*:  /usr/share/openstack-dashboard/openstack_dashboard/dashboards/

_50_thrifty.py:  /usr/share/openstack-dashboard/openstack_dashboard/enabled/_50_thrifty.py

_55_thrifty_admin.py:  /usr/share/openstack-dashboard/openstack_dashboard/enabled/_55_thrifty_admin.py

### 3. Restart Horizon.

`service apache2 restart`