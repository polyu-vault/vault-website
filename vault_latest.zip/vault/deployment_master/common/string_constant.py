QueryLogStatus_SUCCESS = 'Success'
QueryLogStatus_FAILURE = 'Failure'
QueryLogStatus_PROCESSING = 'Processing'

TenantUpdateJobStatus_PENDING="Pending"
TenantUpdateJobStatus_PROCESSING="Processing"