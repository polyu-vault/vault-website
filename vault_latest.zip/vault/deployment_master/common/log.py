# A common logging util
import logging

logging.basicConfig(level=logging.DEBUG)

def getLogger(name="Default"):
    return logging.getLogger(name)
